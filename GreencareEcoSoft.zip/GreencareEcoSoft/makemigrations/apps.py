from django.apps import AppConfig


class MakemigrationsConfig(AppConfig):
    name = 'makemigrations'
