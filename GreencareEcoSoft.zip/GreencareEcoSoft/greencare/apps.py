from django.apps import AppConfig


class GreencareConfig(AppConfig):
    name = 'greencare'
