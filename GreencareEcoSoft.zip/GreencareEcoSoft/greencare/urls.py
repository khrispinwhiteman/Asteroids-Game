from django.conf.urls import url

from greencare import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^about/$', views.about, name='about'),
    url(r'^contact/$', views.contactus, name='contact'),
    url(r'^services/$', views.services, name='services'),
    url(r'^services/(?P<slug>[-\w]+)/$', views.service_detail, name='service_detail'),
    url(r'^newslist/$', views.newslist, name='newslist'),
    url(r'^newslist/(?P<news_id>\d+)/$', views.newsdetail, name='newsdetail'),
]