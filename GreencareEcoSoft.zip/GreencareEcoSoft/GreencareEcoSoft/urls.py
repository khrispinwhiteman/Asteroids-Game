from django.conf import settings
from django.conf.urls import url
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    url('admin/', admin.site.urls),
    url(r'', include('greencare.urls')),
    #path('summernote/', include('django_summernote.urls')),
    url(r'^froala_editor/', include('froala_editor.urls')),
]

admin.site.site_header = 'Greencare Eco Administration'
admin.site.index_title = 'System Applications'

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
